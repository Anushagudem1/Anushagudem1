import { loginApp } from "../pages/loginAmazonApp";
import { AddProductToCart } from "../pages/AddEarPodsTocart";

const AddCart = new loginApp();
const product = new AddProductToCart();

describe('E-commerce',async()=>{
    beforeEach(()=>{
        var email="prashanthgudem777@gmail.com";
        var password="9515536927";

        cy.visit('https://www.amazon.com/');
        AddCart.LoginApp(email,password);
        AddCart.verifyAmazonLogo();
    })

    it('Add product to cart',()=>{
        var productsname="earpods";

        product.SearchProduct(productsname);
        product.selectThirdProductAddToCart();
        product.verifyAddedProductToCart();
    })
})