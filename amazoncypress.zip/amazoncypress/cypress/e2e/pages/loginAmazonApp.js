import LoginObject from "../selectors/LoginObject";
import 'cypress-xpath';
export class loginApp{

    navigateToSignPage(){
        cy.xpath(LoginObject.Signin).click();
        cy.get(LoginObject.ContinueBtn).should('be.visible');
    }

    enterEmail(email){
        cy.get(LoginObject.Email).type(email);
    }

    clickOnContinueBtn(){
        cy.get(LoginObject.ContinueBtn).click();
        cy.get(LoginObject.signinBtn).should('be.visible');
    }

    enterpassword(password){
        cy.get(LoginObject.password).type(password);
    }

    clickOnSignBtn(){
        cy.get(LoginObject.signinBtn).click();
    }

    verifyAmazonLogo(){
        cy.get(LoginObject.verifyLogo).should('be.visible');
    }

    LoginApp(email,password){
        this.navigateToSignPage();
        this.enterEmail(email);
        this.clickOnContinueBtn();
        this.enterpassword(password);
        this.clickOnSignBtn();
    }

}