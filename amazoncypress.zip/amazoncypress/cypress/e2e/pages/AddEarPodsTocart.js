
import LoginObject from "../selectors/LoginObject";
export class AddProductToCart{

    SearchProduct(ProductName){
        //Enter earpods in search box
        cy.get(LoginObject.searchBox).type(ProductName);
        //Click on search button
        cy.get(LoginObject.searchBtn).click();
    }

    selectThirdProductAddToCart(){
        //find out 3rd product from the list and click on it
        cy.get("[data-action='puis-card-container-declarative']").find(LoginObject.seeOption).eq('2').click();
        //After click on 3rd product then add to cart button should be visible 
       // cy.xpath(LoginObject.addToCartBtn).should('be.visible');
        //click on addto cart button
       // cy.xpath(LoginObject.addToCartBtn).click();
        //after click on add to cart button then added to cart text should be visible
        cy.xpath(LoginObject.addedToCartSuccessNotifycation).should('be.visible');
        cy.get(LoginObject.verifyaddToCart).should('be.visible');
    }

    verifyAddedProductToCart(){
        //click on cart button
        cy.get(LoginObject.cartBtn).click();
        //verify cart button having count 1 is prasent or not
        //cy.xpath(LoginObject.addedCartCount).should('be.visible');
        //In cart button Amazon cart is empty text should not be visible
        //cy.xpath(LoginObject.amazonCartIsEmptyTxt).should('not.be.visible');
        cy.xpath(LoginObject.verifyAddedProduct).should('be.visible');
    }
}