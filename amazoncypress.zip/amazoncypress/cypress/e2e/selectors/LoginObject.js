export default{

    Signin:"//span[text()='Hello, sign in']",
    Email:'#ap_email',
    ContinueBtn:'#continue',
    password:'#ap_password',
    signinBtn:"#signInSubmit",
    verifyLogo:"#nav-logo-sprites",

    searchBox:'#twotabsearchtextbox',
    searchBtn:"#nav-search-submit-button",
    seeOption:"[class='a-button-text']",
    addToCartBtn:"//div[@class='simpleBundleSection']//span//input[@class='a-button-input']",
    addedToCartSuccessNotifycation:"//div[@class='a-changeover s-atc-success-notification']",
    verifyaddToCart:"[class='a-row s-atc-group']",
    cartBtn:"#nav-cart-count-container",
    addedCartCount:"//div[@id='nav-cart-count-container']//span[text()='1']",
    amazonCartIsEmptyTxt:"//h1[text()[normalize-space()='Your Amazon Cart is empty.']]",
    verifyAddedProduct:"(//div[@class='sc-list-item-content'])[1]",
}